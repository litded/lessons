# Contacts 

email: evlasov@specialist.ru
email: evgeny_vlasov@yahoo.com

github repo: https://github.com/vlasove/go3_grpc